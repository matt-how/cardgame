import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Matt on 25/01/2017.
 */

public class Deck {
    public static int DECKSIZE = 30;

    ArrayList<Card> cards = new ArrayList<Card>();

    public Deck(){
        setupTestDeck();
    }

    public void shuffle(){
        int j;
        for(int i = DECKSIZE-1; i>0;i--){
            j = (int )(Math.random() * i);
            Collections.swap(cards,i,j);
        }
    }

    public void setupTestDeck()
    {
        for(int i = 0; i < DECKSIZE; i+=2){
            cards.add(new Card(0));
            cards.add(new Card(1));
        }
    }

    public Card drawCard()
    {
        return(cards.remove(cards.size()-1));
    }


}
