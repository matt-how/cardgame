import org.jsfml.graphics.*;
import org.jsfml.window.*;
import org.jsfml.window.event.*;
import java.util.*;

/**
 * Created by Matt on 18/01/2017.
 */
public class Driver
{
    private static int screenWidth  = 1024;
    private static int screenHeight = 768;
    public static int MOVESPEED = 2;



    public static void run() {
        //
        // Create a window
        //
        RenderWindow window = new RenderWindow( );
        window.create(new VideoMode(screenWidth, screenHeight),"Card Quest", WindowStyle.DEFAULT);
        window.setFramerateLimit(30); // 60FPS master-race
        boolean playersTurn = true;
        int playerLocation = 0;
        Square[] squares = new Square[14];
        ArrayList<Button> buttons = new ArrayList<Button>();
        squares[0] = new Square(20,250,2,0);
        for(int i = 1; i<14; i++) {
            squares[i] = new Square((i*70)+20,250,0, i);
        }
        squares[11] = new Square(11*70+20,250,1,0);
        squares[13] = new Square(13*70+20,250,1,0);


        Button moveButton = new Button("move.png",800,500,0);
        buttons.add(moveButton);
        Deck deck = new Deck();
        deck.shuffle();

        ArrayList<Card> hand = new ArrayList<Card>();
        for(int i = 0; i<5;i++){
            hand.add(deck.drawCard());
            hand.get(i).setX(i*(int)hand.get(i).getWidth());
            hand.get(i).setY(screenHeight - (int)hand.get(i).getHeight());
        }


        //
        // Main loop
        //
        while (window.isOpen( )) {
            // Clear the screen
            window.clear(Color.RED);
            //place updates between here and display

            for(int i = 0; i<14; i++) {
                squares[i].draw(window);
            }
            moveButton.draw(window);
            for(int i=0; i < hand.size();i++){
                hand.get(i).draw(window);
            }




            // Handle any events
            for (Event event : window.pollEvents( )) {
                if (event.type == Event.Type.CLOSED) {
                    // the user pressed the close button
                    window.close( );
                }
                if(event.type == Event.Type.MOUSE_BUTTON_PRESSED && playersTurn==true){
                    for(int i = 0; i < buttons.size(); i++){
                        if(Mouse.getPosition(window).x > buttons.get(i).x && Mouse.getPosition(window).x < buttons.get(i).x+buttons.get(i).getWidth() && Mouse.getPosition(window).y > buttons.get(i).y && Mouse.getPosition(window).y < buttons.get(i).y+buttons.get(i).getHeight()) {
                            switch (buttons.get(i).getButtonID()){
                                case 0:
                                    squares[playerLocation].moveContents(squares[playerLocation+MOVESPEED]);
                                    playerLocation+=MOVESPEED;

                            }
                            playersTurn = false;
                        }

                    }
                }
            }

            //enemy turn goes here

            playersTurn = true;
            //

            // Update the display with any changes
            window.display( );
        }
    }


    public static void main (String args[ ]) {
        run();
    }
}
